package csvs

import "fmt"

func CheckLoadCsv(){
	//二次处理
	fmt.Println("csv配置读取完成---ok")
}